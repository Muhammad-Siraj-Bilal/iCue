#include <Wire.h>
#include <I2Cdev.h>
#include <MPU6050.h>
// #include "BluetoothSerial.h"
#include <WiFi.h>
#include <FirebaseESP32.h>

// Replace with your Wi-Fi credentials
#define WIFI_SSID "MDX welcomes you"
#define WIFI_PASSWORD "MdxL0vesyou"

// #define WIFI_SSID "@Apple Home"
// #define WIFI_PASSWORD "1234512345"

// Replace with your Firebase project credentials
#define FIREBASE_HOST "https://icue-f15ff-default-rtdb.firebaseio.com/"
#define FIREBASE_AUTH "KRkaTYtlmuiQ1wJ2OwrvEuhXslZhimC7j5UF1GuX"

FirebaseData firebaseData;
FirebaseAuth auth;
FirebaseConfig config;

// BluetoothSerial SerialBT;
MPU6050 mpu;

#define DEADZONE 3  
#define STABLE_THRESHOLD 30  
#define CALIBRATION_TIME 3000   
#define SHAKE_THRESHOLD 2.5     
#define GYRO_THRESHOLD 40 
#define NO_MOVEMENT_TIME 1500
#define STABILITY_TOLERANCE 0.15 // Small fluctuation allowance      
#define BUFFER_SIZE 40 // 40 samples = 2 seconds (1s before, 1s after)

// std::vector<float> accelXBuffer(BUFFER_SIZE), accelYBuffer(BUFFER_SIZE), accelZBuffer(BUFFER_SIZE);
// std::vector<float> gyroXBuffer(BUFFER_SIZE), gyroYBuffer(BUFFER_SIZE), gyroZBuffer(BUFFER_SIZE);

// std::vector<float> accelXBuffer(BUFFER_SIZE, 0), accelYBuffer(BUFFER_SIZE, 0), accelZBuffer(BUFFER_SIZE, 0);
// std::vector<float> gyroXBuffer(BUFFER_SIZE, 0), gyroYBuffer(BUFFER_SIZE, 0), gyroZBuffer(BUFFER_SIZE, 0);

float accelXBuffer[BUFFER_SIZE], accelYBuffer[BUFFER_SIZE], accelZBuffer[BUFFER_SIZE];
float gyroXBuffer[BUFFER_SIZE], gyroYBuffer[BUFFER_SIZE], gyroZBuffer[BUFFER_SIZE];

// std::vector<float> accelXBuffer, accelYBuffer, accelZBuffer;
// std::vector<float> gyroXBuffer, gyroYBuffer, gyroZBuffer;

int16_t ax, ay, az, gx, gy, gz;
int16_t ax_offset, ay_offset, az_offset;
int16_t gx_offset, gy_offset, gz_offset;
float sumAccelX = 0, sumAccelY = 0, sumAccelZ = 0;
float sumGyroX = 0, sumGyroY = 0, sumGyroZ = 0;
int sampleCount = 0;
unsigned long lastMotionTime = 0;  // Time when motion was last detected
unsigned long stableStartTime = 0; // Time when no motion started
bool isCalibrated = false;
bool isMoving = false;
int bufferIndex = 0;
bool shotDetected = false;
unsigned long shotStartTime = 0;

void setup() {
    Serial.begin(115200);
    // SerialBT.begin("ESP32_MPU6050");
    Wire.begin();
    mpu.initialize();

    // Connect to WiFi
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    Serial.print("Connecting to WiFi...");
    // SerialBT.print("Connecting to WiFi...");
    while (WiFi.status() != WL_CONNECTED) {
        delay(1000);
        Serial.print(".");
        // SerialBT.print(".");
    }
    Serial.println("\nConnected to WiFi!");
    // SerialBT.println("\nConnected to WiFi!");

    // Configure Firebase
    config.host = FIREBASE_HOST;
    config.signer.tokens.legacy_token = FIREBASE_AUTH;

    Firebase.begin(&config, &auth);
    Firebase.reconnectWiFi(true);

    Serial.println("Firebase connected!");
    // Firebase.setFloat(firebaseData, "/connection_data/completed", 1);
    // SerialBT.println("Firebase connected!");

    Serial.println("Hold cue stick still for calibration...");
    Firebase.setFloat(firebaseData, "/callibration_data/completed", 0);
    // SerialBT.println("Hold cue stick still for calibration...");
    
    unsigned long startTime = millis();
    
    while (millis() - startTime < CALIBRATION_TIME) {
        mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);
        
        float gyroMagnitude = sqrt(gx * gx + gy * gy + gz * gz) / 131.0;
        Serial.println(gyroMagnitude);
        Firebase.setFloat(firebaseData, "/callibration_data/measurements", gyroMagnitude);
        // SerialBT.println(gyroMagnitude);

        if (gyroMagnitude > STABLE_THRESHOLD) {
            Serial.println("Motion detected. Restarting calibration...");
            // SerialBT.println("Motion detected. Restarting calibration...");
            startTime = millis();  
        }

        delay(50);
    }

    Serial.println("Calibrating MPU6050...");
    // SerialBT.println("Calibrating MPU6050...");
    
    mpu.CalibrateAccel(20);
    mpu.CalibrateGyro(20);
    
    ax_offset = mpu.getXAccelOffset();
    ay_offset = mpu.getYAccelOffset();
    az_offset = mpu.getZAccelOffset();
    gx_offset = mpu.getXGyroOffset();
    gy_offset = mpu.getYGyroOffset();
    gz_offset = mpu.getZGyroOffset();

    Serial.println("Calibration Complete!");
    Firebase.setFloat(firebaseData, "/callibration_data/completed", 1);
    // SerialBT.println("Calibration Complete!");

    Serial.println("Applying Offsets...");
    // SerialBT.println("Applying Offsets...");
    
    mpu.setXAccelOffset(ax_offset);
    mpu.setYAccelOffset(ay_offset);
    mpu.setZAccelOffset(az_offset);
    mpu.setXGyroOffset(gx_offset);
    mpu.setYGyroOffset(gy_offset);
    mpu.setZGyroOffset(gz_offset);

    // accelXBuffer.resize(BUFFER_SIZE, 0);
    // accelYBuffer.resize(BUFFER_SIZE, 0);
    // accelZBuffer.resize(BUFFER_SIZE, 0);
    // gyroXBuffer.resize(BUFFER_SIZE, 0);
    // gyroYBuffer.resize(BUFFER_SIZE, 0);
    // gyroZBuffer.resize(BUFFER_SIZE, 0);

    Serial.println("Offsets Applied! Start Moving.");
    // SerialBT.println("Offsets Applied! Start Moving.");

    isCalibrated = true;
}

void sendBufferedDataToFirebase(int bufferIndex) {
    if (!Firebase.ready()) {
        Serial.println("Firebase not ready.");
        return;
    }

    FirebaseJson json;
    FirebaseJsonArray accelXArray, accelYArray, accelZArray;
    FirebaseJsonArray gyroXArray, gyroYArray, gyroZArray;

    // bufferIndex = bufferIndex - 40;
    // bufferIndex = max(0, bufferIndex - 40);
    // Send last 1 second of data before the shot and 1 second after
    // int startIdx = (bufferIndex + BUFFER_SIZE - 20) % BUFFER_SIZE;  // Start 1 sec before
    int startIndex = (bufferIndex - BUFFER_SIZE + BUFFER_SIZE) % BUFFER_SIZE; // Get the starting index for sending data
    for (int i = 0; i < BUFFER_SIZE; i++) {
        // int idx = bufferIndex;
        // int idx;
        int idx = (startIndex + i) % BUFFER_SIZE;

        // if (i <= bufferIndex) {  
        //     // First part: Go backward from bufferIndex to 0
        //     idx = bufferIndex - i;
        // } else {  
        //     // Second part: Go backward from 39 to bufferIndex
        //     idx = 40 - (i - bufferIndex);
        // }

        // if (i < (BUFFER_SIZE / 2)) {  
        //     // First part: Go forward from bufferIndex to 39
        //     idx = (bufferIndex + i) % BUFFER_SIZE;
        // } else {  
        //     // Second part: Go forward from 0 to bufferIndex
        //     idx = (i - (BUFFER_SIZE / 2));
        // }

        accelXArray.add(accelXBuffer[idx]);
        accelYArray.add(accelYBuffer[idx]);
        accelZArray.add(accelZBuffer[idx]);
        gyroXArray.add(gyroXBuffer[idx]);
        gyroYArray.add(gyroYBuffer[idx]);
        gyroZArray.add(gyroZBuffer[idx]);
        // bufferIndex = bufferIndex + 1;
    }

    json.set("accelX", accelXArray);
    json.set("accelY", accelYArray);
    json.set("accelZ", accelZArray);
    json.set("gyroX", gyroXArray);
    json.set("gyroY", gyroYArray);
    json.set("gyroZ", gyroZArray);

    if (Firebase.set(firebaseData, "/shot_data", json)) {
        Serial.println("Shot data sent to Firebase!");
    } else {
        Serial.print("Firebase Error: ");
        Serial.println(firebaseData.errorReason());
    }

    json.clear();
    accelXArray.clear();
    accelYArray.clear();
    accelZArray.clear();
    gyroXArray.clear();
    gyroYArray.clear();
    gyroZArray.clear();
}

void loop() {
    if (!isCalibrated) return;

    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

    float accelX = ax / 16384.0;
    float accelY = ay / 16384.0;
    float accelZ = az / 16384.0;
    float gyroX = gx / 131.0;
    float gyroY = gy / 131.0;
    float gyroZ = gz / 131.0;

    float accelMagnitude = sqrt(accelX * accelX + accelY * accelY + accelZ * accelZ);
    float gyroMagnitude = sqrt(gyroX * gyroX + gyroY * gyroY + gyroZ * gyroZ);

    Serial.print(accelX);
    Serial.print(", "); Serial.print(accelY);
    Serial.print(", "); Serial.print(accelZ);
    Serial.print(", "); Serial.print(gyroX);
    Serial.print(", "); Serial.print(gyroY);
    Serial.print(", "); Serial.println(gyroZ);

    Serial.print(accelMagnitude);
    Serial.print(", "); Serial.println(gyroMagnitude);

    // Store data in a circular buffer (always keeps last 1 sec of data)
    accelXBuffer[bufferIndex] = accelX;
    accelYBuffer[bufferIndex] = accelY;
    accelZBuffer[bufferIndex] = accelZ;
    gyroXBuffer[bufferIndex] = gyroX;
    gyroYBuffer[bufferIndex] = gyroY;
    gyroZBuffer[bufferIndex] = gyroZ;

    bufferIndex = (bufferIndex + 1) % BUFFER_SIZE; // Circular buffer index update

    Serial.println(bufferIndex);

    // Detect shot based on acceleration or gyro threshold
    if (!shotDetected && (accelMagnitude > SHAKE_THRESHOLD && gyroMagnitude > GYRO_THRESHOLD)) {
        shotDetected = true;
        shotStartTime = millis();
        Serial.println("Shot detected! Recording post-shot data...");
    }

    // Record for 1 second after the shot
    if (shotDetected && millis() - shotStartTime > 1000) {
        sendBufferedDataToFirebase(bufferIndex);
        shotDetected = false;
    }

    delay(50);  // Adjust sample rate
}